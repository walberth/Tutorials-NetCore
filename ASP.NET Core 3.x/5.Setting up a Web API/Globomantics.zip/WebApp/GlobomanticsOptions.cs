﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp
{
    public class GlobomanticsOptions
    {
        public int BoldConferenceAttendeeThreshold { get; set; }
    }
}
