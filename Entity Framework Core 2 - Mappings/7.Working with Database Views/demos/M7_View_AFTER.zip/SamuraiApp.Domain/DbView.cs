﻿namespace SamuraiApp.Domain
{
    public abstract class DbView
    {
    }
}