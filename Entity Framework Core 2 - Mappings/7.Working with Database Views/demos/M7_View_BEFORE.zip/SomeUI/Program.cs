﻿using Microsoft.EntityFrameworkCore;
using SamuraiApp.Data;
using System.Linq;

namespace SomeUI
{
    internal class Program
    {
        private static SamuraiContext _context = new SamuraiContext();
        private static void Main(string[] args)
        {
      
        }
      
    }
}